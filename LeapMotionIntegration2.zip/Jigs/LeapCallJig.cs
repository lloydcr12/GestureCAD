﻿using Autodesk.AutoCAD.EditorInput;
using Autodesk.AutoCAD.Geometry;

namespace LeapMotionIntegration
{
  public class LeapCallJig : LeapJig
  {
    private CallibrationListener _listener;

    public LeapCallJig(CallibrationListener listener)
    {
      _listener = listener;
    }

    protected override SamplerStatus SamplerData(JigPrompts prompts)
    {
      // We don't really need a point, but we do need some
      // user input event to allow us to loop, processing
      // for the Leap Motion input

      var opts =
        new JigPromptPointOptions(
          "\nTap on the surface or escape to quit"
        );
      opts.UserInputControls =
        UserInputControls.NullResponseAccepted;

      var pr = prompts.AcquirePoint(opts);
      if (pr.Status == PromptStatus.OK)
      {
        ForceMessage();

        if (!_listener.FoundLocation)
        {
          return SamplerStatus.OK;
        }
      }
      else if (pr.Status == PromptStatus.None)
      {
        if (
          _listener.Position.DistanceTo(Point3d.Origin) >
          Tolerance.Global.EqualPoint
        )
        {
          _listener.Location = _listener.Position;
          _listener.FoundLocation = true;
        }
      }
      return SamplerStatus.Cancel;
    }
  }
}
