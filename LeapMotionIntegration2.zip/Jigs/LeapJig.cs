﻿using Autodesk.AutoCAD.EditorInput;
using Autodesk.AutoCAD.GraphicsInterface;

namespace LeapMotionIntegration
{
  public class LeapJig : DrawJig
  {
    public LeapJig()
    {
    }

    protected override SamplerStatus Sampler(JigPrompts prompts)
    {
      return SamplerData(prompts);
    }

    protected virtual SamplerStatus SamplerData(JigPrompts prompts)
    {
      // We don't really need a point, but we do need some
      // user input event to allow us to loop, processing
      // for the Leap Motion input

      var opts =
        new JigPromptPointOptions(
          "\nSelect a point."
        );

      var pr = prompts.AcquirePoint(opts);
      if (pr.Status == PromptStatus.OK)
      {
        ForceMessage();
        return SamplerStatus.OK;
      }
      return SamplerStatus.Cancel;
    }

    protected override bool WorldDraw(WorldDraw wd)
    {
      return WorldDrawData(wd);
    }

    protected virtual bool WorldDrawData(WorldDraw wd)
    {
      return true;
    }

    protected void ForceMessage()
    {
      // Set the cursor without ectually moving it - enough to
      // generate a Windows message

      var pt = System.Windows.Forms.Cursor.Position;
      System.Windows.Forms.Cursor.Position =
        new System.Drawing.Point(pt.X, pt.Y);
    }
  }
}
