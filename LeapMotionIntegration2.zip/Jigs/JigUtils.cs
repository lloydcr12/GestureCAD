﻿using System;
using Autodesk.AutoCAD.Geometry;
using Autodesk.AutoCAD.DatabaseServices;

namespace LeapMotionIntegration
{
  class JigUtils
  {
    // Custom ArcTangent method, as the Math.Atan
    // doesn't handle specific cases

    public static double Atan(double y, double x)
    {
      if (x > 0)
        return Math.Atan(y / x);
      else if (x < 0)
        return Math.Atan(y / x) - Math.PI;
      else  // x == 0
      {
        if (y > 0)
          return Math.PI;
        else if (y < 0)
          return -Math.PI;
        else // if (y == 0) theta is undefined
          return 0.0;
      }
    }

    // Computes Angle between current direction
    // (vector from last vertex to current vertex)
    // and the last pline segment

    public static double ComputeAngle(
      Vector3d dir, Vector3d xdir, Matrix3d ucs
    )
    {
      var v = dir / 2;
      var cos = v.DotProduct(xdir);
      var sin =
        v.DotProduct(
          Vector3d.ZAxis.TransformBy(ucs).CrossProduct(xdir)
        );
      return Atan(sin, cos);
    }

    public static Matrix3d Dcs2Wcs(AbstractViewTableRecord vtr)
    {
      var mat = Matrix3d.PlaneToWorld(vtr.ViewDirection);
      mat =
        Matrix3d.Displacement(vtr.Target - Point3d.Origin) * mat;
      mat =
        Matrix3d.Rotation(
          -vtr.ViewTwist, vtr.ViewDirection, vtr.Target
        ) * mat;
      return mat;
    }
  }
}