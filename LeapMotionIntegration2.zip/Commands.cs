﻿using System.Threading;
using Autodesk.AutoCAD.ApplicationServices.Core;
using Autodesk.AutoCAD.DatabaseServices;
using Autodesk.AutoCAD.EditorInput;
using Autodesk.AutoCAD.Geometry;
using Autodesk.AutoCAD.Runtime;
using Leap;

namespace LeapMotionIntegration
{
  public class Commands
  {
    [CommandMethod("LEAP")]
    public void LeapMotion()
    {
      // Cancel out of any existing geometry creation

      MessageCommands.LeapMotionMessagesCancel();

      var doc =
        Application.DocumentManager.MdiActiveDocument;
      var db = doc.Database;
      var ed = doc.Editor;

      using (var tr = doc.TransactionManager.StartTransaction())
      {
        var ms =
          (BlockTableRecord)tr.GetObject(
            db.CurrentSpaceId, OpenMode.ForWrite
          );

        // Create our jig

        var lj = new LeapPolyJig(doc);

        // Create a camera for our current document to adjust
        // the view

        var cam = new Camera(doc);

        // Creating a blank form makes sure the SyncContext is
        // set properly for this thread

        using (var f1 = new Form1())
        {
          var ctxt = SynchronizationContext.Current;
          try
          {
            if (ctxt == null)
            {
              throw
                new System.Exception(
                  "Current sync context is null."
                );
            }

            // Create our navigation listener to receive events

            var listener = new NavigationListener(ed, cam, ctxt, lj);
            using (listener)
            {
              if (listener == null)
              {
                throw
                  new System.Exception(
                    "Could not create listener."
                  );
              }

              // Use the listener to create the Leap Motion
              // controller

              using (var controller = new Controller(listener))
              {
                if (controller == null)
                {
                  throw
                    new System.Exception(
                      "Could not create controller."
                    );
                }

                // Run the jig

                PromptResult pr;
                do
                {
                  pr = ed.Drag(lj);
                  if (lj.EnterPressed)
                  {
                    if (lj.Drawing)
                    {
                      var ent = lj.GeneratePathEntity();
                      ent.ColorIndex = 1;
                      ms.AppendEntity(ent);
                      tr.AddNewlyCreatedDBObject(ent, true);
                      lj.Vertices.Clear();
                      lj.Drawing = false;
                    }
                    else
                    {
                      cam.Reset();
                    }
                    lj.EnterPressed = false;
                  }
                } while (pr.Status != PromptStatus.Cancel);
              }
            }

            tr.Commit();
          }
          catch (System.Exception ex)
          {
            ed.WriteMessage("\nException: {0}", ex.Message);
          }
        }
      }
    }

    [CommandMethod("LEAPEXT")]
    public void LeapMotionExtrusion()
    {
      var doc =
        Application.DocumentManager.MdiActiveDocument;
      var db = doc.Database;
      var ed = doc.Editor;

      try
      {
        // Cancel out of any existing geometry creation

        MessageCommands.LeapMotionMessagesCancel();

        var callList = new CallibrationListener(ed);
        using (callList)
        {
          if (callList == null)
          {
            throw
              new System.Exception("Could not create listener.");
          }

          var lj = new LeapCallJig(callList);

          // Use the listener to create the Leap Motion
          // controller

          using (var callCont = new Controller(callList))
          {
            if (callCont == null)
            {
              throw
                new System.Exception("Could not create controller.");
            }

            callCont.EnableGesture(
              Gesture.GestureType.TYPEKEYTAP
            );
            callCont.EnableGesture(
              Gesture.GestureType.TYPESCREENTAP
            );

            // Run the jig

            PromptResult pr;
            do
            {
              pr = ed.Drag(lj);
              if (
                callList.FoundLocation &&
                callList.Location.DistanceTo(Point3d.Origin) >
                  Tolerance.Global.EqualPoint
              )
              {
                break;
              }
            } while (pr.Status != PromptStatus.Cancel);

            if (callList.FoundLocation)
            {
              var loc = callList.Location;
              ed.WriteMessage(
                "\nFound surface at a height of {0:F1} mm.", loc.Z
              );
            }
            else
            {
              return;
            }
          }
        }

        using (var tr = doc.TransactionManager.StartTransaction())
        {
          // Create our jig

          var lej = new LeapExtJig(doc);

          // Create a camera for our current document to adjust
          // the view

          var cam = new Camera(doc);

          // Creating a blank form makes sure the SyncContext is
          // set properly for this thread

          using (var f1 = new Form1())
          {
            var ctxt = SynchronizationContext.Current;
            if (ctxt == null)
            {
              throw
                new System.Exception(
                  "Current sync context is null."
                );
            }

            // Create our extrusion listener to receive events

            var listener =
              new ExtrusionListener(
                ed, cam, ctxt, callList.Location, lej
              );
            using (listener)
            {
              if (listener == null)
              {
                throw
                  new System.Exception(
                    "Could not create listener."
                  );
              }

              // Use the listener to create the Leap Motion
              // controller

              using (var controller = new Controller(listener))
              {
                if (controller == null)
                {
                  throw
                    new System.Exception(
                      "Could not create controller."
                    );
                }

                controller.EnableGesture(
                  Gesture.GestureType.TYPEKEYTAP
                );
                controller.EnableGesture(
                  Gesture.GestureType.TYPESCREENTAP
                );
                controller.EnableGesture(
                  Gesture.GestureType.TYPECIRCLE
                );

                // Run the jig

                PromptResult pr;
                do
                {
                  pr = ed.Drag(lej);
                  if (lej.EnterPressed)
                  {
                    var btr =
                      (BlockTableRecord)tr.GetObject(
                        db.CurrentSpaceId, OpenMode.ForWrite
                      );
                    if (lej.HasCircle)
                    {
                      var sol = lej.ExtrudeCircle();
                      if (sol != null)
                      {
                        // Add it to the drawing

                        btr.AppendEntity(sol);
                        tr.AddNewlyCreatedDBObject(sol, true);
                      }
                      lej.HasCircle = false;
                    }

                    if (lej.HasBoundary)
                    {
                      using (var ent = lej.CreateBoundary())
                      {
                        var sol =
                          lej.ExtrudeBoundary(
                            ent, lej.BoundaryHeight
                          );
                        if (sol != null)
                        {
                          // Add it to the drawing

                          btr.AppendEntity(sol);
                          tr.AddNewlyCreatedDBObject(sol, true);
                        }
                        lej.HasBoundary = false;
                        lej.Vertices.Clear();
                      }
                    }

                    if (lej.Drawing)
                    {
                      lej.Vertices.Clear();
                      lej.Drawing = false;
                    }

                    lej.EnterPressed = false;
                  }
                } while (pr.Status != PromptStatus.Cancel);
              }
            }

            tr.Commit();
          }
        }
      }
      catch (System.Exception ex)
      {
        ed.WriteMessage("\nException: {0}", ex.Message);
      }
    }
  }

  public class MessageCommands
  {
    private static MessageListener _listener = null;
    private static Controller _controller = null;

    [CommandMethod("LEAPMSGS")]
    public static void LeapMotionMessages()
    {
      var doc =
        Application.DocumentManager.MdiActiveDocument;
      var db = doc.Database;
      var ed = doc.Editor;

      if (_listener == null || _controller == null)
      {
        // Creating a blank form makes sure the SyncContext is
        // set properly for this thread

        if (SynchronizationContext.Current == null)
        {
          using (var f1 = new Form1()) { }
        }

        var ctxt = SynchronizationContext.Current;

        try
        {
          if (ctxt == null)
          {
            ed.WriteMessage(
              "\nCurrent sync context is null."
            );
            return;
          }

          if (_listener == null)
          {
            _listener = new MessageListener(ed, ctxt);
            if (_listener == null)
            {
              ed.WriteMessage("\nCould not create listener.");
              return;
            }

            if (_controller == null)
            {
              _controller = new Controller(_listener);
              if (_controller == null)
              {
                ed.WriteMessage("\nCould not create controller.");
                return;
              }
            }
          }
        }
        catch (System.Exception ex)
        {
          ed.WriteMessage("\nException: {0}", ex.Message);
        }
      }
    }

    [CommandMethod("LEAPMSGSX")]
    public static void LeapMotionMessagesCancel()
    {
      if (_controller != null)
      {
        _controller.Dispose();
        _controller = null;
      }
      if (_listener != null)
      {
        _listener.Dispose();
        _listener = null;
      }
    }
  }
}
