﻿using Autodesk.AutoCAD.EditorInput;
using Autodesk.AutoCAD.Geometry;
using Leap;

namespace LeapMotionIntegration
{
  public class CallibrationListener : Listener
  {
    public Point3d Location { get; set; }
    public Point3d Position { get; set; }
    public bool FoundLocation { get; set; }
    private Editor _ed;

    public CallibrationListener(Editor ed)
    {
      FoundLocation = false;
      Location = Point3d.Origin;
      _ed = ed;
    }

    public override void OnFrame(Controller controller)
    {
      // Get the most recent frame

      var frame = controller.Frame();
      var gestures = frame.Gestures();

      foreach (var gesture in gestures)
      {
        if (
          gesture.Type == Gesture.GestureType.TYPESCREENTAP ||
          gesture.Type == Gesture.GestureType.TYPEKEYTAP
        )
        {
          var pointables = gesture.Pointables;
          if (pointables != null && pointables.Count > 0)
          {
            var lowest = ListenerUtils.LowestPointable(pointables);
            FoundLocation = (lowest != null);
            if (FoundLocation)
            {
              Location =
                ListenerUtils.Vector2Point3d(lowest.TipPosition);
            }
          }
          else
          {
            _ed.WriteMessage("\nNo pointables.\n");
          }
        }
      }

      if (!FoundLocation)
      {
        var pointables = frame.Pointables;
        if (pointables != null && pointables.Count > 0)
        {
          var lowest = ListenerUtils.LowestPointable(pointables);
          var tip = lowest.TipPosition;
          Position = ListenerUtils.Vector2Point3d(tip);
        }
      }
    }
  }
}