﻿using System;
using System.Threading;
using Autodesk.AutoCAD.DatabaseServices;
using Autodesk.AutoCAD.EditorInput;
using Autodesk.AutoCAD.Geometry;
using Leap;

namespace LeapMotionIntegration
{
  public class ExtrusionListener : Listener
  {
    private Editor _ed;
    private Camera _cam;
    private SynchronizationContext _ctxt;
    private Point3d _origin;
    private LeapExtJig _jig;
    private ViewTableRecord _vtr = null;
    private Matrix3d _rotMat, _dcs;
    private double _scale;
    private Vector3d _yOffset;
    private bool _viewNeedsUpdate;

    const int DistanceThreshhold = 10;

    public ExtrusionListener(
      Editor ed, Camera cam, SynchronizationContext ctxt,
      Point3d origin, LeapExtJig jl
    )
    {
      _ed = ed;
      _vtr = _ed.GetCurrentView();
      _cam = cam;
      _ctxt = ctxt;
      _origin = origin;
      _jig = jl;
      _viewNeedsUpdate = true;
    }

    private void viewUpdated()
    {
      _vtr = _ed.GetCurrentView();
      _viewNeedsUpdate = true;
    }

    private void updateViewInformation()
    {
      var ctr = _vtr.CenterPoint;
      var ctr3d = new Point3d(ctr.X, ctr.Y, 0);
      var hgt = _vtr.Height;
      var wid = _vtr.Width;
      var min = hgt < wid ? hgt : wid;
      _yOffset = new Vector3d(0, -hgt / 3, 0);
      _scale = min / 200;
      _jig.CursorRadius = hgt / 100;

      // Apply the view's rotation, so we compensate

      var rot =
        JigUtils.ComputeAngle(
          _vtr.ViewDirection,
          Vector3d.YAxis,
          _ed.CurrentUserCoordinateSystem
        );

      _rotMat =
        Matrix3d.Rotation(
          rot + Math.PI, Vector3d.ZAxis, Point3d.Origin
        );

      // To get the cursor centered on the screen, we'll
      // displace it by the center point of the view.
      // Start by getting the view's DCS matrix, then transform
      // the displacement from the center

      _dcs = JigUtils.Dcs2Wcs(_vtr);
      _rotMat =
        Matrix3d.Displacement(ctr3d.GetAsVector().TransformBy(_dcs))
        * _rotMat;
    }

    private void WriteLine(String line)
    {
      if (_ed != null)
      {
        _ctxt.Post(a => { _ed.WriteMessage(line + "\n"); }, null);
      }
    }

    private void CallOnCam(SendOrPostCallback cb)
    {
      if (_cam == null)
        WriteLine("Cam is null.");
      else
        _ctxt.Post(cb, null);
    }

    private void Reset()
    {
      CallOnCam(
        a =>
        {
          _cam.Reset();
          viewUpdated();
        }
      );
    }

    private void Zoom(double factor)
    {
      CallOnCam(
        a =>
        {
          _cam.Zoom(factor);
          viewUpdated();
        }
      );
    }

    private void Pan(double leftRight, double upDown)
    {
      CallOnCam(
        a =>
        {
          _cam.Pan(leftRight, upDown);
          viewUpdated();
        }
      );
    }

    private void Orbit(Vector3d axis, double angle)
    {
      CallOnCam(
        a =>
        {
          _cam.Orbit(axis, angle);
          viewUpdated();
        }
      );
    }

    private void OrbitVertical(double angle)
    {
      CallOnCam(
        a =>
        {
          _cam.OrbitVertical(angle);
          viewUpdated();
        }
      );
    }

    public override void OnDisconnect(Controller controller)
    {
      WriteLine("Disconnected");
    }

    public override void OnFrame(Controller controller)
    {
      try
      {
        // Do some calcs related to the current view

        if (_viewNeedsUpdate)
        {
          updateViewInformation();

          _jig.HasCircle = false;
          _jig.HasBoundary = false;
          _jig.Drawing = false;
          _jig.Vertices.Clear();

          _viewNeedsUpdate = false;
        }

        // Get the most recent frame

        var frame = controller.Frame();
        var hands = frame.Hands;
        var numHands = hands.Count;

        _jig.FrameId = frame.Id;
        _jig.CodePath = frame.Fingers.Count;

        bool onSurface = false;

        var pointables = frame.Pointables;
        if (pointables != null && pointables.Count > 0)
        {
          //var lowest = ListenerUtils.LowestPointable(pointables);
          var lowest = pointables[0];
          if (lowest != null)
          {
            // Is the lowest pointer's tip close enough to the
            // surface?

            var tip = lowest.TipPosition;
            var level = GetLevel(tip);
            onSurface = Math.Abs(level) < DistanceThreshhold;

            // Set the cursor position

            _jig.PosFromSurface = level;
            _jig.Position = GetPosition(tip);

            // If we're on the surface, check for gestures

            if (onSurface)
            {
              _jig.ShowCursor = true;

              if (
                !_jig.Drawing &&
                !_jig.HasBoundary &&
                !_jig.HasCircle
              )
              {
                var gestures = frame.Gestures();
                if (gestures != null && gestures.Count > 0)
                {
                  foreach (var gesture in gestures)
                  {
                    var gestPoints = gesture.Pointables;
                    if (gestPoints != null)
                    {
                      var lowPoint = gestPoints[0];
                        //ListenerUtils.LowestPointable(gestPoints);
                      if (
                        lowPoint == null ||
                        GetLevel(lowest.TipPosition) >
                          level + DistanceThreshhold
                      )
                      {
                        continue;
                      }
                    }

                    switch (gesture.Type)
                    {
                      case Gesture.GestureType.TYPECIRCLE:
                        {
                          var circle = new CircleGesture(gesture);

                          if (
                            circle != null && circle.Progress >= 0.8
                          )
                          {
                            _jig.CircleCenter =
                              GetPosition(circle.Center);
                            _jig.CircleRadius =
                              circle.Radius * _scale;
                            _jig.HasCircle = true;
                          }
                          break;
                        };

                      case Gesture.GestureType.TYPEKEYTAP:
                        {
                          var tap = new KeyTapGesture(gesture);
                          if (tap != null)
                          {
                            var tip2 = tap.Position;
                            _jig.PosFromSurface = GetLevel(tip2);
                            _jig.AddFirstVertex(GetPosition(tip2));
                            _jig.Drawing = true;
                          }
                          break;
                        };
                      case Gesture.GestureType.TYPESCREENTAP:
                        {
                          var tap = new ScreenTapGesture(gesture);
                          if (tap != null)
                          {
                            var tip2 = tap.Position;
                            _jig.PosFromSurface = GetLevel(tip2);
                            _jig.AddFirstVertex(GetPosition(tip2));
                            _jig.Drawing = true;
                          }
                          break;
                        };
                      default:
                        break;
                    }
                  }
                }
              }
            }
            else // && !onSurface
            {
              _jig.ShowCursor = false;
            }
          }
        }

        // Only proceed if we have at least one hand

        if (
          numHands >= 1 && !onSurface &&
          !(_jig.HasCircle || _jig.HasBoundary || _jig.Drawing)
        )
        {
          // Get the first hand and its velocity to check for
          // zoom or pan

          var hand = hands[0];
          var handVel = hand.PalmVelocity;
          if (handVel == null)
          {
            handVel = new Vector(0, 0, 0);
          }

          // Check if the hand has any fingers

          var fingers = hand.Fingers;
          var ptrs = frame.Pointables;

          // Only proceed if we see at least two fingers detected

          if (fingers.Count == 0 && ptrs.Count == 0)
          {
            _jig.ShowCursor = false;
          }
          else if (fingers.Count > 2)
          {
            _jig.ShowCursor = false;

            // Set a flag to see whether we detect zoom or pan

            bool zoomOrPan = false;

            // Create an AutoCAD vector from the hand's velocity

            var handVec =
              new Vector3d(handVel.x, handVel.y, handVel.z);

            // Get the largest element and its [absolute] value

            var largestDim = handVec.LargestElement;
            var largestVal = handVec[largestDim];
            var largestAbs = Math.Abs(largestVal);

            // Depending on the largest value we know to zoom or pan

            switch (largestDim)
            {
              case 1:
                if (largestAbs > 250)
                {
                  if (frame.Id % 2 == 0)
                  {
                    WriteLine(
                      "Zoom " + (largestVal < 0 ? "in" : "out")
                    );
                    Zoom(largestVal > 0 ? 1.1 : 0.9);
                  }
                  zoomOrPan = true;
                }
                break;
              default:
                if (largestAbs > 100)
                {
                  var x = 0.02 * -handVel.x / largestAbs;
                  var y = 0.02 * handVel.z / largestAbs;
                  WriteLine(
                    "Pan " +
                    (largestDim == 0 ?
                      (largestVal < 0 ? "left" : "right") :
                      (largestVal < 0 ? "up" : "down")
                    )
                  );
                  Pan(x, y);
                  zoomOrPan = true;
                }
                break;
            }

            // If not zoom or pan, we check for orbit

            if (!zoomOrPan && largestAbs < 100)
            {
              // To determine whether we have to orbit, get the
              // normal to the hand's palm

              var handNorm = hand.PalmNormal;

              if (Math.Abs(handNorm.Roll) > 0.4)
              {
                // Orbit left or right when there is "roll"

                WriteLine(
                  "Orbit " + (handNorm.Roll < 0 ? "right" : "left")
                );
                var zAxis =
                  _ed.CurrentUserCoordinateSystem.
                    CoordinateSystem3d.Zaxis;
                Orbit(zAxis, 0.5 * handNorm.Roll * Math.PI / 12);
              }
              else if (
                handNorm.Pitch < -1.5 || handNorm.Pitch > -1.0
              )
              {
                // Orbit up or down when there is "pitch"

                var pitch =
                  handNorm.Pitch < -1.5 ?
                  handNorm.Pitch + 1.5 :
                  Math.Abs(handNorm.Pitch + 1.0);
                WriteLine(
                  "Orbit " + (pitch < 0 ? "up" : "down")
                );
                OrbitVertical(0.5 * pitch * Math.PI / 12);
              }
            }
          }
        }
      }
      catch (System.Exception ex)
      {
        WriteLine(
          "\nException: " + ex.ToString()
        );
      }
    }

    private double GetLevel(Vector v)
    {
      return v.y - _origin.Z;
    }

    private Point3d GetPosition(Vector v)
    {
      // Return the position (passed in as a Vector, v) relative to
      // an origin (pt) with a certain scale factor (fac) and
      // screen transformation (mat)

      return
        (
          (
            ListenerUtils.Vector2Point3d(v) -
            _origin.GetAsVector()
          ) * _scale
        )
        .TransformBy(_rotMat) +_yOffset.TransformBy(_dcs);
    }
  }
}