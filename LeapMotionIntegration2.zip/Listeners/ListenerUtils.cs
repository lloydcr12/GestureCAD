﻿using Autodesk.AutoCAD.Geometry;
using Leap;

namespace LeapMotionIntegration
{
  class ListenerUtils
  {
    public static Point3d Vector2Point3d(Vector vec)
    {
      return new Point3d(vec.x, -vec.z, vec.y);
    }

    public static Pointable LowestPointable(PointableList pl)
    {
      // Get the lowest pointable, and see whether we're on
      // the surface

      Pointable lowPoint = null;
      double lowest = 1000; // Set to a high value
      foreach (var pointable in pl)
      {
        var tip = pointable.TipPosition;
        if (tip.y < lowest)
        {
          lowPoint = pointable;
          lowest = tip.y;
        }
      }
      return lowPoint;
    }
  }
}
