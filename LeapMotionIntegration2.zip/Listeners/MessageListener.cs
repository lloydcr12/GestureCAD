﻿using System;
using System.Threading;
using System.Runtime.InteropServices;
using Autodesk.AutoCAD.EditorInput;
using Leap;

namespace LeapMotionIntegration
{
  public class MessageListener : Listener
  {
    [DllImport(
      "user32.dll",
      CharSet = CharSet.Auto,
      CallingConvention = CallingConvention.StdCall
      )
    ]
    public static extern void mouse_event(
      uint dwFlags, uint dx, uint dy,
      uint cButtons, uint dwExtraInfo
    );

    private const int MOUSEEVENTF_LEFTDOWN = 0x02;
    private const int MOUSEEVENTF_LEFTUP = 0x04;
    private const int MOUSEEVENTF_RIGHTDOWN = 0x08;
    private const int MOUSEEVENTF_RIGHTUP = 0x10;

    private Editor _ed;
    private SynchronizationContext _ctxt;
    private bool _handling = false;

    public MessageListener(
      Editor ed, SynchronizationContext ctxt
    )
    {
      _ed = ed;
      _ctxt = ctxt;
    }

    public override void OnFrame(Controller controller)
    {
      // Get the most recent frame

      var frame = controller.Frame();
      var hands = frame.Hands;
      var numHands = hands.Count;

      // Only proceed if we have at least one hand

      if (numHands >= 1)
      {
        // Get the first hand and its velocity to check for
        // zoom or pan

        var hand = hands[0];
        var handVel = hand.PalmVelocity;
        if (handVel == null)
          handVel = new Vector(0, 0, 0);

        // Check if the hand has any fingers

        var fingers = hand.Fingers;

        // Only proceed if we see at least two fingers detected

        if (fingers.Count > 2)
        {
          var pos = System.Windows.Forms.Cursor.Position;
          var x = pos.X + (int)handVel.x / 7;
          var y = pos.Y + (int)handVel.z / 7;

          // Set the cursor position

          System.Windows.Forms.Cursor.Position =
            new System.Drawing.Point(x, y);

          if (!_handling && Math.Abs(handVel.y) < 30)
          {
            foreach (var finger in fingers)
            {
              // If at least one finger has velocity,
              // simulate a mouse-click

              if (Math.Abs(finger.TipVelocity.y) > 150)
              {
                mouse_event(
                  MOUSEEVENTF_LEFTDOWN | MOUSEEVENTF_LEFTUP,
                  (uint)x, (uint)y, 0, 0
                );

                // Make sure no further clicks get sent for the
                // specified number of seconds

                Handle(1);
                break;
              }
            }
          }

          // Process Windows messages at the end of each frame

          System.Windows.Forms.Application.DoEvents();
        }
      }
    }

    private void Handle(int secs)
    {
      // Only handle an event if one isn't already in progress

      if (!_handling)
      {
        // Set the flag to stop other events being handled for
        // the specified duration

        _handling = true;

        // Set a timer to unset the flag once the duration
        // has passed

        var timer = new System.Windows.Forms.Timer()
        {
          Interval = (int)(secs * 1000),
          Enabled = true
        };

        timer.Tick +=
          (s, e) =>
          {
            _handling = false;
            timer.Stop();
            timer.Dispose();
            timer = null;
          };
      }
    }
  }
}
