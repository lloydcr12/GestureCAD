﻿using Autodesk.AutoCAD.ApplicationServices.Core;
using Autodesk.AutoCAD.EditorInput;
using Autodesk.AutoCAD.Runtime;

[assembly:
  ExtensionApplication(typeof(LeapMotionIntegration.Initialization))
]

namespace LeapMotionIntegration
{
  public class Initialization : IExtensionApplication
  {
    public void Initialize()
    {
      Editor ed =
        Application.DocumentManager.MdiActiveDocument.Editor;
      ed.WriteMessage("Leap Motion integration loaded.");

      MessageCommands.LeapMotionMessages();
    }

    public void Terminate()
    {
      MessageCommands.LeapMotionMessagesCancel();
    }
  }
}
