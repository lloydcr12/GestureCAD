You can download and use these logo images on your own projects.

These images are made available under Creative Commons Attribution-ShareAlike 3.0 Unported License

http://creativecommons.org/licenses/by-sa/3.0/