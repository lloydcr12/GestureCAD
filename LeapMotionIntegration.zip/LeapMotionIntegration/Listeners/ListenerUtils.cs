﻿using Autodesk.AutoCAD.Geometry;
using Leap;

namespace LeapMotionIntegration
{
  class ListenerUtils
  {
    public static Point3d Vector2Point3d(Vector vec)
    {
      return new Point3d(vec.x, -vec.z, vec.y);
    }
  }
}
