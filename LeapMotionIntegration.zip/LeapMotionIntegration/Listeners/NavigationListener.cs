﻿using System;
using System.Threading;
using Autodesk.AutoCAD.EditorInput;
using Autodesk.AutoCAD.Geometry;
using Leap;

namespace LeapMotionIntegration
{
  public class NavigationListener : Listener
  {
    private Editor _ed;
    private Camera _cam;
    private SynchronizationContext _ctxt;
    private LeapPolyJig _jig;

    public NavigationListener(
      Editor ed, Camera cam, SynchronizationContext ctxt, LeapPolyJig jl
    )
    {
      _ed = ed;
      _cam = cam;
      _ctxt = ctxt;
      _jig = jl;
    }

    private void WriteLine(String line)
    {
      if (_ed != null)
      {
        _ctxt.Post(a => { _ed.WriteMessage(line + "\n"); }, null);
      }
    }

    private void CallOnCam(SendOrPostCallback cb)
    {
      if (_cam == null)
        WriteLine("Cam is null.");
      else
        _ctxt.Post(cb, null);
    }

    private void Reset()
    {
      CallOnCam(a => { _cam.Reset(); });
    }

    private void Zoom(double factor)
    {
      CallOnCam(a => { _cam.Zoom(factor); });
    }

    private void Pan(double leftRight, double upDown)
    {
      CallOnCam(a => { _cam.Pan(leftRight, upDown); });
    }

    private void Orbit(Vector3d axis, double angle)
    {
      CallOnCam(a => { _cam.Orbit(axis, angle); });
    }

    private void OrbitVertical(double angle)
    {
      CallOnCam(a => { _cam.OrbitVertical(angle); });
    }

    public override void OnDisconnect(Controller controller)
    {
      WriteLine("Disconnected");
    }

    public override void OnFrame(Controller controller)
    {
      // Get the most recent frame

      var frame = controller.Frame();
      var hands = frame.Hands;
      var numHands = hands.Count;

      // Only proceed if we have at least one hand

      if (numHands >= 1)
      {
        // Get the first hand and its velocity to check for
        // zoom or pan

        var hand = hands[0];
        var handVel = hand.PalmVelocity;
        if (handVel == null)
          handVel = new Vector(0, 0, 0);

        // Check if the hand has any fingers

        var fingers = hand.Fingers;
        var ptrs = frame.Pointables;

        // Only proceed if we see at least two fingers detected

        if (fingers.Count == 0 && ptrs.Count == 0)
        {
          _jig.ShowCursor = false;
        }
        else if (fingers.Count > 2)
        {
          _jig.ShowCursor = false;

          // Set a flag to see whether we detect zoom or pan

          bool zoomOrPan = false;

          // Create an AutoCAD vector from the hand's velocity

          var handVec =
            new Vector3d(handVel.x, handVel.y, handVel.z);

          // Get the largest element and its [absolute] value

          var largestDim = handVec.LargestElement;
          var largestVal = handVec[largestDim];
          var largestAbs = Math.Abs(largestVal);

          // Depending on the largest value we know to zoom or pan

          switch (largestDim)
          {
            case 1:
              if (largestAbs > 250)
              {
                if (frame.Id % 2 == 0)
                {
                  WriteLine(
                    "Zoom " + (largestVal < 0 ? "in" : "out")
                  );
                  Zoom(largestVal > 0 ? 1.1 : 0.9);
                }
                zoomOrPan = true;
              }
              break;
            default:
              if (largestAbs > 100)
              {
                var x = 0.02 * -handVel.x / largestAbs;
                var y = 0.02 * handVel.z / largestAbs;
                WriteLine(
                  "Pan " +
                  (largestDim == 0 ?
                    (largestVal < 0 ? "left" : "right") :
                    (largestVal < 0 ? "up" : "down")
                  )
                );
                Pan(x, y);
                zoomOrPan = true;
              }
              break;
          }

          // If not zoom or pan, we check for orbit

          if (!zoomOrPan && largestAbs < 100)
          {
            // To determine whether we have to orbit, get the normal
            // to the hand's palm

            var handNorm = hand.PalmNormal;

            if (Math.Abs(handNorm.Roll) > 0.4)
            {
              // Orbit left or right when there is "roll"

              WriteLine(
                "Orbit " + (handNorm.Roll < 0 ? "right" : "left")
              );
              var zAxis =
                _ed.CurrentUserCoordinateSystem.CoordinateSystem3d.
                  Zaxis;
              Orbit(zAxis, 0.5 * handNorm.Roll * Math.PI / 12);
            }
            else if (handNorm.Pitch < -1.5 || handNorm.Pitch > -1.0)
            {
              // Orbit up or down when there is "pitch"

              var pitch =
                handNorm.Pitch < -1.5 ?
                handNorm.Pitch + 1.5 :
                Math.Abs(handNorm.Pitch + 1.0);
              WriteLine(
                "Orbit " + (pitch < 0 ? "up" : "down")
              );
              OrbitVertical(0.5 * pitch * Math.PI / 12);
            }
          }
        }
        else
        {
          if (ptrs.Count > 0)
          {
            // Set the cursor position to be the
            // tip of the primary pointable

            var tip = ptrs[0].TipPosition;
            _jig.Position = new Point3d(tip.x, -tip.z, tip.y);
            _jig.ShowCursor = true;
            /*
            if (ptrs.Count > 1)
            {
              var tip2 = ptrs[1].TipPosition;
              _jig.Position2 = new Point3d(tip2.x, -tip2.z, tip2.y);
            }
            else
             */
            {
              _jig.Position2 = Point3d.Origin;
            }
          }
        }
      }
    }
  }
}
