﻿using System;
using Autodesk.AutoCAD.ApplicationServices;
using Autodesk.AutoCAD.DatabaseServices;
using Autodesk.AutoCAD.EditorInput;
using Autodesk.AutoCAD.Geometry;
using Autodesk.AutoCAD.GraphicsInterface;

namespace LeapMotionIntegration
{
  public class LeapPolyJig : LeapJig
  {
    // Internal state

    private Document _doc;
    private Point3dCollection _verts;
    private Point3d _pos;
    private Point3d _pos2;
    private bool _enterPressed;
    private bool _showCursor;
    private bool _drawing;
    private bool _splineVsPline;

    public LeapPolyJig(Document doc)
    {
      // Initialise the various members

      _doc = doc;
      _verts = new Point3dCollection();
      _pos = Point3d.Origin;
      _enterPressed = false;
      _showCursor = false;
      _drawing = false;
      _splineVsPline = false;
    }

    public Point3dCollection Vertices
    {
      get { return _verts; }
      set { _verts = value; }
    }

    public Point3d Position
    {
      get { return _pos; }
      set { _pos = value; }
    }

    public Point3d Position2
    {
      get { return _pos2; }
      set { _pos2 = value; }
    }

    public bool EnterPressed
    {
      get { return _enterPressed; }
      set { _enterPressed = value; }
    }

    public bool ShowCursor
    {
      get { return _showCursor; }
      set { _showCursor = value; }
    }

    public bool Drawing
    {
      get { return _drawing; }
      set { _drawing = value; }
    }

    public bool SplineVsPline
    {
      get { return _splineVsPline; }
      set { _splineVsPline = value; }
    }

    protected override SamplerStatus SamplerData(JigPrompts prompts)
    {
      // We don't really need a point, but we do need some
      // user input event to allow us to loop, processing
      // for the Leap Motion input

      var opts =
        new JigPromptPointOptions(
          "\nEnter to commit polyline/reset view, esc to quit " +
          "or [Pline/Spline]",
          "Pline Spline"
        );
      opts.UserInputControls =
        UserInputControls.NullResponseAccepted;

      var pr = prompts.AcquirePoint(opts);

      switch (pr.Status)
      {
        case PromptStatus.Keyword:
          {
            _splineVsPline = (pr.StringResult == "Spline");
            _drawing = true;
            break;
          }
        case PromptStatus.None:
          {
            _enterPressed = true;
            return SamplerStatus.OK;
          }
        case PromptStatus.OK:
          {
            ForceMessage();
            return SamplerStatus.OK;
          }
      }
      return SamplerStatus.Cancel;
    }

    protected override bool WorldDrawData(WorldDraw wd)
    {
      try
      {
        var vtr = _doc.Editor.GetCurrentView();

        var hgt = vtr.Height;
        var wid = vtr.Width;
        var min = hgt < wid ? hgt : wid;
        var fac = min / 200;
        var pt = _pos * fac;
        var pt2 =
          _pos2.DistanceTo(Point3d.Origin) >
            Tolerance.Global.EqualVector ?
          pt + (_pos2 - _pos) : Point3d.Origin;
        var curRad = hgt / 70;

        // Apply the view's rotation, so we compensate

        var rot =
          JigUtils.ComputeAngle(
            vtr.ViewDirection,
            Vector3d.YAxis,
            _doc.Editor.CurrentUserCoordinateSystem
          );
        var rotMat =
          Matrix3d.Rotation(
            rot + Math.PI, Vector3d.ZAxis, Point3d.Origin
          );

        if (_showCursor)
        {
          DrawSphere(wd, pt, curRad, rotMat, 3);

          if (
            pt2.DistanceTo(Point3d.Origin) >
            Tolerance.Global.EqualVector
          )
          {
            DrawSphere(wd, pt2, curRad, rotMat, 1);
          }
        }

        // If drawing, add vertices when at a reasonable distance
        // from the previous one

        if (_drawing)
        {
          if (
            _verts.Count == 0 ||
            _verts[_verts.Count - 1].DistanceTo(pt) > curRad * 5
          )
          {
            _verts.Add(pt.TransformBy(rotMat));
          }
        }
        else if (_verts.Count > 0)
        {
          // If not drawing and there are vertices, clear them

          _verts.Clear();
        }

        // If we still have vertices in the list...

        if (_verts.Count > 1)
        {
          // Create a polyline or spline and draw it

          using (var ent = GeneratePathEntity())
          {
            ent.ColorIndex = 2;
            ent.WorldDraw(wd);
          }
        }
      }
      catch { }

      return true;
    }

    private void DrawSphere(
      WorldDraw wd, Point3d pt, double curRad, Matrix3d rotMat,
      short colorIndex
    )
    {
      // Get the displacement to the specified position

      var mat = Matrix3d.Displacement(pt.GetAsVector());
      mat = mat.PreMultiplyBy(rotMat);

      // Create and draw our solid

      if (_showCursor)
      {
        using (var cursor = new Solid3d())
        {
          cursor.CreateSphere(curRad);
          cursor.ColorIndex = colorIndex;
          cursor.TransformBy(mat);
          cursor.WorldDraw(wd);
        }
      }
    }

    public Entity GeneratePathEntity()
    {
      return
        (_splineVsPline ?
          (Entity)new Spline(_verts, 0, 0.0) :
          new Polyline3d(Poly3dType.SimplePoly, _verts, false)
        );
    }
  }
}
