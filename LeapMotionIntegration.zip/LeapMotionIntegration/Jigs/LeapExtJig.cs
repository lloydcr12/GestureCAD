﻿using System;
using Autodesk.AutoCAD.ApplicationServices;
using Autodesk.AutoCAD.DatabaseServices;
using Autodesk.AutoCAD.EditorInput;
using Autodesk.AutoCAD.Geometry;
using AcGi = Autodesk.AutoCAD.GraphicsInterface;

namespace LeapMotionIntegration
{
  public class LeapExtJig : LeapJig
  {
    // Internal state

    private Document _doc;

    private Point3d _pos;
    private bool _showCursor;
    private double _curRad;

    private bool _hasCircle;
    private Point3d _cirCen;
    private double _cirRad;
    private double _cirHgt;

    private bool _hasBoundary;
    private Point3dCollection _verts;
    private double _bndHgt;
    private bool _drawing;
    private bool _splineVsPline;

    private bool _enterPressed;

    public LeapExtJig(Document doc)
    {
      // Initialise the various members

      _doc = doc;
      _showCursor = false;
      _hasCircle = false;
      _hasBoundary = false;
      _verts = new Point3dCollection();
      _drawing = false;
      _splineVsPline = true;
      _enterPressed = false;
    }

    public Point3d Position
    {
      get { return _pos; }
      set { _pos = value; }
    }

    public bool ShowCursor
    {
      get { return _showCursor; }
      set { _showCursor = value; }
    }

    public double CursorRadius
    {
      get { return _curRad; }
      set { _curRad = value; }
    }

    public bool HasCircle
    {
      get { return _hasCircle; }
      set { _hasCircle = value; }
    }

    public Point3d CircleCenter
    {
      get { return _cirCen; }
      set { _cirCen = value; }
    }

    public double CircleRadius
    {
      get { return _cirRad; }
      set { _cirRad = value; }
    }

    public double CircleHeight
    {
      get { return _cirHgt; }
      set { _cirHgt = value; }
    }

    public bool HasBoundary
    {
      get { return _hasBoundary; }
      set { _hasBoundary = value; }
    }

    public Point3dCollection Vertices
    {
      get { return _verts; }
      set { _verts = value; }
    }

    public double BoundaryHeight
    {
      get { return _bndHgt; }
      set { _bndHgt = value; }
    }

    public bool Drawing
    {
      get { return _drawing; }
      set { _drawing = value; }
    }

    public bool SplineVsPline
    {
      get { return _splineVsPline; }
      set { _splineVsPline = value; }
    }

    public bool EnterPressed
    {
      get { return _enterPressed; }
      set { _enterPressed = value; }
    }

    public void AddFirstVertex(Point3d pt)
    {
      _verts.Clear();
      _verts.Add(ZtoZero(pt));
      _hasBoundary = false;
    }

    protected override SamplerStatus SamplerData(JigPrompts prompts)
    {
      // We don't really need a point, but we do need some
      // user input event to allow us to loop, processing
      // for the Leap Motion input

      var opts =
        new JigPromptPointOptions(
          "\nEnter to commit polyline/reset view, esc to quit " +
          "or [Pline/Spline]",
          "Pline Spline"
        );
      opts.UserInputControls =
        UserInputControls.NullResponseAccepted;

      var pr = prompts.AcquirePoint(opts);

      switch (pr.Status)
      {
        case PromptStatus.Keyword:
          {
            _splineVsPline = (pr.StringResult == "Spline");
            _drawing = true;
            _hasBoundary = false;
            _verts.Clear();
            break;
          }
        case PromptStatus.None:
          {
            _enterPressed = true;
            return SamplerStatus.OK;
          }
        case PromptStatus.OK:
          {
            ForceMessage();
            return SamplerStatus.OK;
          }
      }
      return SamplerStatus.Cancel;
    }

    protected override bool WorldDrawData(AcGi.WorldDraw wd)
    {
      try
      {
        // If within 2cm of the surface, draw a circular cursor

        if (_showCursor)
        {
          DrawCircle(
            wd, _pos, _curRad, (short)(_drawing ? 1 : 3), true
          );
        }

        // If a circular gesture has resulted in a circle being
        // drawn...

        if (_hasCircle)
        {
          // We'll create a circle to represent the location of
          // the gesture

          bool drewExtrusion = false;

          var curPos = new Point2d(_pos.X, _pos.Y);
          var cirCen = new Point2d(_cirCen.X, _cirCen.Y);
          if (curPos.GetDistanceTo(cirCen) < _cirRad * 2)
          {
            _cirHgt = _pos.Z - _cirCen.Z;
            if (_cirHgt > 0.1 && _cirRad > 0.1)
            {
              using (var sol = new Solid3d())
              {
                sol.CreateFrustum(
                  _cirHgt, _cirRad, _cirRad, _cirRad
                );
                var mat =
                  Matrix3d.Displacement(
                    new Vector3d(
                      _cirCen.X, _cirCen.Y, _cirHgt / 2
                    )
                  );
                sol.TransformBy(mat);

                wd.Geometry.Draw(sol);
                drewExtrusion = true;
              }
            }
          }
          if (!drewExtrusion)
          {
            DrawCircle(wd, _cirCen, _cirRad, 2, false);
          }
        }
        else if (_hasBoundary)
        {
          // Create a polyline or spline and draw it

          using (var ent = CreateBoundary())
          {
            bool drewExtrusion = false;

            // We know it's a curve, hopefully it's closed

            var cur = ent as Curve;
            if (cur != null && cur.Closed && cur.Area > 0)
            {
              if (cur.Bounds.HasValue)
              {
                var ext = cur.Bounds.Value;
                if (
                  _pos.X > ext.MinPoint.X &&
                  _pos.X < ext.MaxPoint.X &&
                  _pos.Y > ext.MinPoint.Y &&
                  _pos.Y < ext.MaxPoint.Y
                )
                {
                  var v0 = _verts[0];
                  _bndHgt = _pos.Z - v0.Z;

                  using (var sol = ExtrudeBoundary(ent))
                  {
                    if (sol != null)
                    {
                      wd.Geometry.Draw(sol);
                      drewExtrusion = true;
                    }
                  }
                }
              }
            }
            if (!drewExtrusion)
            {
              ent.ColorIndex = 1;
              ent.WorldDraw(wd);
            }
          }
        }
        else
        {
          // If drawing, add vertices when at a reasonable distance
          // from the previous one

          if (_drawing)
          {
            var pt = ZtoZero(_pos);
            if (
              _verts.Count == 0 ||
              _verts[_verts.Count - 1].DistanceTo(pt) > _curRad * 3
            )
            {
              // Are we near the beginning? Close the curve

              if (
                _verts.Count > 3 &&
                pt.DistanceTo(_verts[0]) < _curRad * 3
              )
              {
                _verts.Add(_verts[0]);
                _hasBoundary = true;
                _drawing = false;
              }
              else
              {
                _verts.Add(pt);
              }
            }
          }
          else if (_verts.Count > 0)
          {
            // If not drawing and there are vertices, clear them

            _verts.Clear();
          }
        }

        // If we still have vertices in the list...

        if (_verts.Count > 1 && !_hasBoundary)
        {
          // Create a polyline or spline and draw it

          using (var ent = CreateBoundary())
          {
            ent.ColorIndex = 2;
            ent.WorldDraw(wd);
          }
        }
      }
      catch (System.Exception ex)
      {
        _doc.Editor.WriteMessage(
          "\nException in jig: {0}", ex
        );
      }

      return true;
    }

    private Point3d ZtoZero(Point3d pt)
    {
      return new Point3d(pt.X, pt.Y, 0);
    }

    private void DrawCircle(
      AcGi.WorldDraw wd, Point3d cen, double rad,
      short colorIndex, bool fill
    )
    {
      // Draw our circular cursor on the XY plane

      var ft = wd.SubEntityTraits.FillType;
      var col = wd.SubEntityTraits.Color;

      wd.SubEntityTraits.FillType =
        fill ? AcGi.FillType.FillAlways : AcGi.FillType.FillNever;
      wd.SubEntityTraits.Color = colorIndex;
      wd.Geometry.Circle(ZtoZero(cen), rad, Vector3d.ZAxis);
      
      wd.SubEntityTraits.FillType = ft;
      wd.SubEntityTraits.Color = col;
    }

    public Entity CreateBoundary()
    {
      // Create and return a spline or a polyline boundary

      if (_splineVsPline)
      {
        // Spline

        return (Entity)new Spline(_verts, 0, 0.0);
      }
      else
      {
        // Polyline

        // If it's closed, we ignore the last vertex

        var closed = 
          _hasBoundary &&
          _verts[0].DistanceTo(_verts[_verts.Count - 1]) <
            Tolerance.Global.EqualPoint;
        var numVerts = closed ? _verts.Count - 1 : _verts.Count;

        // Populate the polyline with the vertex data

        var pl = new Polyline(numVerts);
        for (int i=0; i < numVerts; i++)
        {
          var pt = _verts[i];
          pl.AddVertexAt(i, new Point2d(pt.X, pt.Y), 0, 0, 0);
        }

        // Set its closed status, as appropriate

        pl.Closed = closed;
        
        return pl;
      }
    }

    internal Solid3d ExtrudeCircle()
    {
      Solid3d sol = null;
      if (_cirHgt > 0)
      {
        try
        {
          var mat =
            Matrix3d.Displacement(
              new Vector3d(_cirCen.X, _cirCen.Y, _cirHgt / 2)
            );

          // Create the cylindrical solid

          sol = new Solid3d();
          sol.CreateFrustum(_cirHgt, _cirRad, _cirRad, _cirRad);
          sol.TransformBy(mat);
        }
        catch { }
      }
      return sol;
    }

    internal Solid3d ExtrudeBoundary(Entity boundary)
    {
      Solid3d sol = null;
      if (_bndHgt > 0.1)
      {
        try
        {
          // Extrude the boundary entity by the height

          sol = new Solid3d();
          var sob = new SweepOptionsBuilder();
          sob.BasePoint = _verts[0];
          sol.CreateExtrudedSolid(
            boundary,
            new Vector3d(0, 0, _bndHgt),
            sob.ToSweepOptions()
          );
        }
        catch { }
      }
      return sol;
    }
  }
}